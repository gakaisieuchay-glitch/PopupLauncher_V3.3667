package com.example.popuplauncher

import android.graphics.Rect
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Root/SU detector and command runner. Priority #1 in the launch engine.
 *
 * V3 Phase 2: previously every call (`id`, `am start`, `dumpsys`, `am task resize`)
 * forked a brand-new `su -c "..."` process — up to ~6 su spawns for one popup launch
 * with resize. [RootShellSession] now keeps ONE interactive `su` process warm and pipes
 * commands through its stdin/stdout, closing it automatically after
 * [IDLE_SESSION_TIMEOUT_MS] of inactivity. If the pooled session ever fails (dead
 * process, desynced pipe, timeout), [exec] transparently falls back to the old
 * one-off `su -c` process for that single call and discards the broken session —
 * pooling is a pure optimization layered on a path that still works on its own.
 */
object RootManager {

    private const val TAG = "RootManager"
    private const val CHECK_TIMEOUT_MS = 1_200L
    private const val EXEC_TIMEOUT_MS = 4_000L
    private const val WINDOWING_MODE_FREEFORM = 5

    private const val TASK_LOOKUP_ATTEMPTS = 4
    private const val TASK_LOOKUP_RETRY_DELAY_MS = 150L

    /** Close the pooled su session after this long without a new command. */
    private const val IDLE_SESSION_TIMEOUT_MS = 8_000L
    private const val ROOT_CHECK_CACHE_MS = 5_000L

    private val sessionMutex = Mutex()
    private var session: RootShellSession? = null
    private var idleReleaseJob: Job? = null
    private val sessionScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cachedRootAccess: Boolean? = null
    @Volatile private var rootAccessCheckedAt: Long = 0L

    /** True when a functional su binary can execute `id` as uid 0. */
    suspend fun hasRootAccess(): Boolean {
        val now = SystemClock.elapsedRealtime()
        cachedRootAccess?.let { cached ->
            if (now - rootAccessCheckedAt < ROOT_CHECK_CACHE_MS) return cached
        }
        val detected = exec("id", CHECK_TIMEOUT_MS)?.let { result ->
            result.exitCode == 0 && result.output.contains("uid=0")
        } == true
        cachedRootAccess = detected
        rootAccessCheckedAt = now
        return detected
    }

    fun invalidateRootAccessCache() {
        cachedRootAccess = null
        rootAccessCheckedAt = 0L
    }

    /**
     * Warms the reusable su session while the user is looking at the app picker.
     * This moves the root handshake off the actual app-launch critical path.
     */
    suspend fun prewarm(): Boolean =
        if (hasRootAccess()) {
            exec("true", 800L) != null
        } else {
            false
        }

    /**
     * Starts the target activity in Freeform mode and best-effort resizes its task.
     * With the session pool warm, this is normally 1 (no resize) or 2 (with resize,
     * assuming the task is found on the first dumpsys poll) su round-trips instead of
     * a fresh process per command.
     */
    suspend fun launchFreeform(
        targetPackage: String,
        targetActivity: String,
        bounds: Rect? = null
    ): Boolean {
        val component = "$targetPackage/$targetActivity"
        if (!COMPONENT_REGEX.matches(component)) {
            Log.w(TAG, "Component không hợp lệ: $component")
            return false
        }

        val command = "am start -n ${shellQuote(component)} --windowingMode $WINDOWING_MODE_FREEFORM"
        val result = exec(command, EXEC_TIMEOUT_MS)
        if (result == null) {
            invalidateRootAccessCache()
            Log.w(TAG, "Không thể thực thi lệnh qua su")
            return false
        }

        Log.d(TAG, "am start exitCode=${result.exitCode}: ${result.output.take(500)}")
        if (result.exitCode != 0) {
            invalidateRootAccessCache()
            return false
        }

        if (bounds != null && bounds.width() > 0 && bounds.height() > 0) {
            applyBoundsBestEffort(targetPackage, bounds)
        }
        return true
    }

    /** Best-effort only: failure here must never invalidate a successful launch. */
    private suspend fun applyBoundsBestEffort(targetPackage: String, bounds: Rect) {
        repeat(TASK_LOOKUP_ATTEMPTS) { index ->
            val attempt = index + 1
            val dump = exec("dumpsys activity activities", CHECK_TIMEOUT_MS)
            val taskId = dump?.output?.let { findTaskId(it, targetPackage) }

            if (taskId != null) {
                val boundsArg = "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"
                val resizeResult = exec("am task resize $taskId $boundsArg", EXEC_TIMEOUT_MS)
                Log.d(
                    TAG,
                    "am task resize taskId=$taskId bounds=$boundsArg exitCode=${resizeResult?.exitCode}"
                )
                return
            }

            if (attempt < TASK_LOOKUP_ATTEMPTS) delay(TASK_LOOKUP_RETRY_DELAY_MS)
        }
        Log.w(
            TAG,
            "Không tìm thấy TaskRecord của $targetPackage để resize (best-effort, ROM có thể không hỗ trợ)."
        )
    }

    /**
     * Parse output of "dumpsys activity activities" to find the newest taskId matching
     * the package. Expected line shape: "* TaskRecord{... #1234 A=com.example.package ...}".
     */
    private fun findTaskId(dumpsysOutput: String, packageName: String): Int? {
        // Single backslash per escape: inside a raw ("""...""") string, "\\d" is a literal
        // backslash + "d", NOT the regex "\d" — that bug made task lookup silently fail.
        val regex = Regex("""#(\d+)\s+A=${Regex.escape(packageName)}\b""")
        return regex.findAll(dumpsysOutput).lastOrNull()?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"

    /**
     * Runs [command] through the pooled interactive su session when possible; falls back to
     * a one-off `su -c` process if the session is missing, dead, or times out. Any pooled
     * failure invalidates the session so the next call opens a fresh one instead of reusing
     * a pipe that may now be out of sync with what the shell has already consumed.
     */
    private suspend fun exec(command: String, timeoutMs: Long): CommandResult? {
        scheduleIdleRelease()

        val pooledResult = sessionMutex.withLock {
            val current = session ?: openSession()?.also { session = it } ?: return@withLock null
            val result = current.run(command, timeoutMs)
            if (result == null) {
                current.close()
                session = null
            }
            result
        }

        return pooledResult ?: runOneOff(command, timeoutMs)
    }

    private fun openSession(): RootShellSession? =
        runCatching { RootShellSession() }.getOrElse {
            Log.d(TAG, "Không thể mở phiên su thường trực, sẽ dùng chế độ one-off: ${it.message}")
            null
        }

    private fun scheduleIdleRelease() {
        idleReleaseJob?.cancel()
        idleReleaseJob = sessionScope.launch {
            delay(IDLE_SESSION_TIMEOUT_MS)
            sessionMutex.withLock {
                session?.close()
                session = null
            }
        }
    }

    /**
     * Generic entry point for privileged one-line commands that aren't part of the launch
     * flow (e.g. the Super Boost optimization toggle). Reuses the same pooled session.
     */
    suspend fun runCommand(command: String, timeoutMs: Long = EXEC_TIMEOUT_MS): Boolean =
        exec(command, timeoutMs)?.exitCode == 0

    /** Explicit, immediate teardown — call when the app is sure no more root work is coming. */
    fun releaseSession() {
        idleReleaseJob?.cancel()
        idleReleaseJob = null
        sessionScope.launch {
            sessionMutex.withLock {
                session?.close()
                session = null
            }
        }
    }

    /** One-off `su -c` process: the original, previously-verified fallback path. */
    private suspend fun runOneOff(command: String, timeoutMs: Long): CommandResult? =
        withContext(Dispatchers.IO) {
            try {
                coroutineScope {
                    val process = ProcessBuilder("su", "-c", command)
                        .redirectErrorStream(true)
                        .start()

                    // Drain stdout concurrently with waitFor() so a large dumpsys response
                    // can't fill the pipe and deadlock the child process.
                    val outputJob = async(Dispatchers.IO) {
                        process.inputStream.bufferedReader().use { it.readText() }
                    }

                    if (!process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) {
                        process.destroy()
                        if (process.isAlive) process.destroyForcibly()
                        outputJob.cancel()
                        return@coroutineScope null
                    }

                    CommandResult(process.exitValue(), outputJob.await())
                }
            } catch (t: Throwable) {
                Log.d(TAG, "SU không khả dụng: ${t.message}")
                null
            }
        }

    data class CommandResult(val exitCode: Int, val output: String)

    private val COMPONENT_REGEX =
        Regex("""^[A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+$""")

    /**
     * One long-lived interactive `su` process, driven over stdin/stdout with a unique
     * end-of-output marker per command so several sequential commands share a single
     * process instead of re-paying the su handshake every time.
     *
     * The blocking read loop runs on a dedicated single-thread executor so it can be
     * bounded with a real timeout via `Future.get()` — a plain `BufferedReader.readLine()`
     * has no per-call timeout and would otherwise hang forever on a wedged shell.
     */
    private class RootShellSession {
        private val process = ProcessBuilder("su")
            .redirectErrorStream(true)
            .start()
        private val stdin: BufferedWriter = process.outputStream.bufferedWriter()
        private val stdout: BufferedReader = process.inputStream.bufferedReader()
        private val readerExecutor = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "PopupLauncher-RootSessionReader").apply { isDaemon = true }
        }

        suspend fun run(command: String, timeoutMs: Long): CommandResult? =
            withContext(Dispatchers.IO) {
                if (!process.isAlive) return@withContext null

                val marker = "__popup_launcher_end_${System.nanoTime()}__"
                try {
                    stdin.write(command)
                    stdin.newLine()
                    // "\$?" is a literal, escaped "$?" — expanded by the su shell itself
                    // (not by Kotlin) to the exit status of the command on the line above.
                    stdin.write("echo $marker:\$?")
                    stdin.newLine()
                    stdin.flush()
                } catch (t: Throwable) {
                    return@withContext null
                }

                val future: Future<CommandResult?> = readerExecutor.submit(Callable {
                    val output = StringBuilder()
                    var parsed: CommandResult? = null
                    while (true) {
                        val line = stdout.readLine() ?: break
                        if (line.startsWith(marker)) {
                            val exitCode = line.substringAfter(':', "-1").toIntOrNull() ?: -1
                            parsed = CommandResult(exitCode, output.toString())
                            break
                        }
                        output.append(line).append('\n')
                    }
                    parsed
                })

                try {
                    future.get(timeoutMs, TimeUnit.MILLISECONDS)
                } catch (t: TimeoutException) {
                    // The reader thread may still be blocked on readLine(); it unblocks and
                    // dies on its own once close() tears the process/pipe down below.
                    future.cancel(true)
                    null
                } catch (t: Throwable) {
                    null
                }
            }

        fun close() {
            runCatching { stdin.write("exit\n"); stdin.flush() }
            runCatching { stdin.close() }
            runCatching { stdout.close() }
            runCatching { process.destroy() }
            readerExecutor.shutdownNow()
        }
    }
}
