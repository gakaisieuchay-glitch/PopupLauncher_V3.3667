# Phase 2 — Execution Engine: real Root/Shizuku pooling

This file was created empty in the previous draft (the coroutine-migration pass).
This revision adds what was actually missing: connection **pooling**, plus two real
bugs found during review.

## Bugs fixed (found in the previous draft, present in both RootManager.kt and
## ShellCommandService.kt)

`findTaskId()`'s regex was written as:
```kotlin
Regex("""#(\\d+)\\s+A=${Regex.escape(packageName)}\\b""")
```
Inside a Kotlin **raw** (triple-quoted) string, `\\` is two literal backslashes, not an
escape sequence. So `\\d` is *not* the regex `\d` (a digit) — it's "a literal backslash,
then the letter d", which never appears in real `dumpsys` output. Task lookup (and
therefore the window-resize step) silently failed every time. Fixed to a single
backslash per escape (`\d`, `\s`, `\b`), matching what a raw string actually needs.

## What was already good and is kept as-is

The previous draft's move from a permanent `ExecutorService` to a `SupervisorJob +
Dispatchers.IO` scope, and from callback-based Shizuku binding to
`suspendCancellableCoroutine`, is a real improvement and untouched here. Its
`async`-based concurrent stdout draining (reading output *while* `waitFor()` runs,
instead of after) fixes a genuine latent deadlock risk in the original synchronous
code: a command with enough output to fill the OS pipe buffer could otherwise hang
the child process forever waiting for the app to drain a stream the app wasn't
reading yet.

## What was missing: pooling

The previous draft's own audit doc only describes concurrency changes — it does not
claim pooling, and the code backs that up: every privileged command still spawned a
brand-new process (`RootManager`) or bound/unbound the Shizuku UserService per launch
(`ShizukuManager`, with an explicit comment saying the service is "intentionally
short-lived"). A single popup launch **with** resize was still up to ~6 separate `su`
process spawns.

### RootManager: persistent interactive `su` session

`RootShellSession` opens one `su` process and pipes commands through its stdin,
reading stdout up to a unique per-command marker line (`echo <marker>:$?`) instead of
waiting for the process to exit. The blocking read runs on its own single-thread
executor so it can be bounded with `Future.get(timeout)` — a bare
`BufferedReader.readLine()` has no per-call timeout and would hang forever on a
wedged shell.

Safety net: if the pooled session fails for any reason (dead process, timeout,
I/O error), that single command falls back to the **original** one-off `su -c
command` path, and the broken session is discarded so the next call gets a clean
one. Pooling is a pure optimization on top of a path that already worked; a bug in
the pooling code degrades to the old behavior instead of breaking Root launches.

Idle-release: the session closes on its own after 8s of inactivity, or immediately
when `RootManager.releaseSession()` is called (wired into `FloatingService.removePanel(
releaseShellService = true)` and `onDestroy`, alongside the existing
`ShizukuManager.unbindUserService()` call).

### ShizukuManager: idle-timeout instead of unbind-every-time

`launchViaShizuku`'s `finally` block no longer calls `unbindUserService()`
unconditionally — it schedules a release after 8s of inactivity instead
(`scheduleIdleUnbind`), so opening 2-3 floating apps back to back reuses one bind.
`unbindUserService()` (still called directly from `removePanel`/`onDestroy`/`release()`)
cancels that timer first, so an explicit "user is done" signal always wins over the
timer.

**Trade-off, not hidden:** the UserService is a separate process
(`.processNameSuffix("shell_service")`), so this doesn't count against
`FloatingService`'s own idle-RAM budget, but it does mean a privileged shell process
can sit resident in RAM for up to 8s after the user closes the last Pop-up. If you'd
rather have zero idle privileged processes at the cost of slower back-to-back
launches, lower `IDLE_UNBIND_MS` / `IDLE_SESSION_TIMEOUT_MS` to 0 (equivalent to the
old behavior) or call `unbindUserService()` / `RootManager.releaseSession()` more
eagerly.

## Not verified on-device

Nothing in this file has been compiled or run — this sandbox has no Android SDK and
no network to fetch one. The interactive-`su` stdin/stdout protocol in particular
(different su implementations — Magisk, KernelSU, various OEM su binaries — can
behave slightly differently in interactive mode) is the highest-uncertainty piece of
this phase and needs real testing across at least one Magisk device and one
Shizuku-only (non-root) device before you trust it in daily use.
