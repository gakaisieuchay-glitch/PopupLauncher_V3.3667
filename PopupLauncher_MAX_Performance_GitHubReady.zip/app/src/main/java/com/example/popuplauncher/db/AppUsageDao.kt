package com.example.popuplauncher.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AppUsageDao {

    /**
     * One query for the whole sort step in [AppListHelper.getLaunchableApps] instead of
     * one SharedPreferences read per installed app.
     */
    @Query("SELECT * FROM app_usage")
    suspend fun getAll(): List<AppUsageEntity>

    @Query("SELECT * FROM app_usage WHERE packageName = :packageName")
    suspend fun getByPackage(packageName: String): AppUsageEntity?

    // Deliberately NOT using "INSERT ... ON CONFLICT DO UPDATE" (SQLite upsert syntax,
    // added in 3.24.0): the system SQLite bundled with API 24 devices predates it.
    // REPLACE-on-conflict is supported on every Room-supported API level.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AppUsageEntity)
}
