package com.example.popuplauncher.utils

import android.content.res.Resources
import android.graphics.Rect
import android.os.Build
import android.view.WindowInsets
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Calculates screen-space launch bounds with WindowMetrics and safety insets.
 * Suitable for ActivityOptions.setLaunchBounds() and privileged task-resize commands.
 */
object OverlayBoundsCalculator {

    data class SafeArea(
        val bounds: Rect,
        val leftInset: Int,
        val topInset: Int,
        val rightInset: Int,
        val bottomInset: Int
    )

    fun getSafeArea(windowManager: WindowManager): SafeArea {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics = windowManager.currentWindowMetrics
            val bounds = metrics.bounds
            val types = WindowInsets.Type.systemBars() or
                WindowInsets.Type.displayCutout() or
                WindowInsets.Type.waterfall()
            val insets = metrics.windowInsets.getInsetsIgnoringVisibility(types)
            return SafeArea(
                Rect(bounds),
                insets.left,
                insets.top,
                insets.right,
                insets.bottom
            )
        }

        @Suppress("DEPRECATION")
        val dm = Resources.getSystem().displayMetrics
        return SafeArea(Rect(0, 0, dm.widthPixels, dm.heightPixels), 0, 0, 0, 0)
    }

    fun centeredDp(
        windowManager: WindowManager,
        widthDp: Int,
        heightDp: Int,
        density: Float,
        marginDp: Int = 8
    ): Rect {
        val safe = getSafeArea(windowManager)
        val margin = (marginDp * density).roundToInt()

        val left = safe.bounds.left + safe.leftInset + margin
        val top = safe.bounds.top + safe.topInset + margin
        val right = safe.bounds.right - safe.rightInset - margin
        val bottom = safe.bounds.bottom - safe.bottomInset - margin

        val usableWidth = max(1, right - left)
        val usableHeight = max(1, bottom - top)
        val requestedWidth = max(1, (widthDp * density).roundToInt())
        val requestedHeight = max(1, (heightDp * density).roundToInt())

        val width = requestedWidth.coerceAtMost(usableWidth)
        val height = requestedHeight.coerceAtMost(usableHeight)
        val x = left + (usableWidth - width) / 2
        val y = top + (usableHeight - height) / 2
        return Rect(x, y, x + width, y + height)
    }
}
